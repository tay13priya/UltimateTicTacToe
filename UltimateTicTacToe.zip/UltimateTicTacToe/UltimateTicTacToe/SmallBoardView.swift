//
//  SmallBoardView.swift
//  UltimateTicTacToe
//
//  Created by Parekh, Priya Zara on 11/8/24.
//



import SwiftUI

struct SmallBoardView: View {
    @Binding var board: SmallBoard
    var currentBoard: (Int, Int)?
    var position: (Int, Int)
    var action: (Int, Int) -> Void

    var body: some View {
        VStack {
            if board.winner != .empty {
                // Display the large mark if the board is won
                Text(board.winner.display)
                    .font(.system(size: 150, weight: .bold))
                    .foregroundColor(Color(hex: "#2F4156")) // Use the same color for the mark text
                    .frame(width: 165, height: 165)
                    .background(Color(hex: "#F5EFEB"))
                    .border(Color(hex: "#C8D9E6"))
                    .cornerRadius(5)
            } else {
                // Display the small cells if the board is not won
                ForEach(0..<3, id: \.self) { row in
                    HStack {
                        ForEach(0..<3, id: \.self) { col in
                            self.cellView(row: row, col: col)
                
                        }
                    }
                }
            }
        }
        .padding(10)
        .background(self.boardBackgroundColor)
        .cornerRadius(10)
        .overlay(self.boardOutline)
    }

    private func cellView(row: Int, col: Int) -> some View {
        let index = row * 3 + col
        return CellView(mark: board.cells[index])
            .onTapGesture {
                if board.cells[index] == .empty, board.winner == .empty {
                    if let currentBoard = currentBoard {
                        if currentBoard == position {
                            print("Cell tapped at (\(row), \(col))")
                            action(row, col)
                        }
                    } else {
                        // Allow any board for the first move
                        print("Cell tapped at (\(row), \(col))")
                        action(row, col)
                    }
                        
                }


            }
    }

    private var boardBackgroundColor: Color {
        if let currentBoard = currentBoard, currentBoard == position {
            return Color(hex: "#87AFC7")
        } else {
            return Color(hex: "#F5EFEB")
        }
    }

    private var boardOutline: some View {
        RoundedRectangle(cornerRadius: 10)
            .stroke(currentBoard ?? (0,1) == position ? Color(hex: "#567C8D") : Color(hex: "#F5EFEB"), lineWidth: 4)
    }
}
