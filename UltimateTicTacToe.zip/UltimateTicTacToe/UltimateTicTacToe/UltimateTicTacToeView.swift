import SwiftUI

struct UltimateTicTacToeView: View {
    @StateObject var viewModel = UltimateTicTacToeViewModel() // Top-level @StateObject
    
    var body: some View {
        MainScreen(viewModel: viewModel)
            .fullScreenCover(isPresented: $viewModel.showingWinScreen) {
                WinScreen(viewModel: viewModel)
            }
            .fullScreenCover(isPresented: $viewModel.showingInfoScreen) {
                InfoScreen(viewModel: viewModel)
            }
    }
}

struct MainScreen: View {
    @ObservedObject var viewModel: UltimateTicTacToeViewModel // Use @ObservedObject here

    var body: some View {
        VStack {
            Text(viewModel.message)
                .font(.system(size: 50, weight: .heavy, design: .serif))
                .foregroundColor(Color(hex: "#567C8D"))
                .padding(3)
            if viewModel.currentBoard == nil {
                Text("Play Anywhere")
                    .font(.system(size: 40, weight: .light, design: .rounded))
                    .foregroundColor(Color(hex: "#567C8D"))
                    .padding(3)
            }
            ZStack {
                Rectangle()
                    .fill(Color(hex: "#2F4156"))
                    .cornerRadius(9)
                    .frame(width: 600, height: 600)
                    .border(Color(hex: "#567C8D"), width: 4)
                    .padding(9)
                
                GridStack(rows: 3, columns: 3) { boardRow, boardCol in
                    SmallBoardView(
                        board: $viewModel.boards[boardRow][boardCol],
                        currentBoard: viewModel.currentBoard,
                        position: (boardRow, boardCol)
                    ) { cellRow, cellCol in
                        viewModel.makeMove(boardIndex: (boardRow, boardCol), cellIndex: (cellRow, cellCol))
                    }
                    .border(Color(hex: "#567C8D"), width: 4)
                    .cornerRadius(9)
                    .padding(1)
                }
            }
            
            Button(action: viewModel.resetGame) {
                Text("reset game ")
                    .font(.system(size: 25, weight: .semibold, design: .monospaced))
                    .padding(19)
                    .background(Color(hex: "#C8D9E6"))
                    .foregroundColor(Color(hex: "#567C8D"))
                    .border(Color(hex: "#F5EFEB"), width: 10)
                    .cornerRadius(6)
                    .padding(17)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(hex: "#2F4156"), lineWidth: 7)
                            .padding()
                    )
            }
        }
    }
}

struct WinScreen: View {
    @ObservedObject var viewModel: UltimateTicTacToeViewModel

    var body: some View {
        VStack {
            Text(viewModel.message)
                .font(.system(size: 50, weight: .heavy, design: .serif))
                .foregroundColor(Color(hex: "#567C8D"))
                .padding(12)
            
            Button(action: {
                viewModel.resetGame()
                viewModel.showingWinScreen = false
            }) {
                Text("reset game ")
                    .font(.system(size: 25, weight: .semibold, design: .monospaced))
                    .padding(19)
                    .background(Color(hex: "#C8D9E6"))
                    .foregroundColor(Color(hex: "#567C8D"))
                    .border(Color(hex: "#F5EFEB"), width: 10)
                    .cornerRadius(6)
                    .padding(17)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(hex: "#2F4156"), lineWidth: 7)
                            .padding()
                    )
            }
            .padding()
        }
    }
}

struct InfoScreen: View {
    @ObservedObject var viewModel: UltimateTicTacToeViewModel

    var body: some View {
        VStack {
            Text("Ultimate Tic Tac Toe")
                .font(.system(size: 70, weight: .heavy, design: .serif))
                .foregroundColor(Color(hex: "#567C8D"))
            
            Text("Made by : Taylor and Priya")
                .font(.system(size: 30, weight: .semibold))
                .foregroundColor(Color(hex: "#567C8D"))
                .padding(.bottom, 15)
            
            Text("How To Play")
                .font(.system(size: 35, weight: .medium))
                .foregroundColor(Color(hex: "#567C8D"))
                .padding(1)
                .underline()
            
            Text("Players take turns placing marks in small tic tac toe boards")
                .font(.system(size: 15))
                .foregroundColor(Color(hex: "#567C8D"))
                .padding(3)
            Text("The cell you play in within a small board determines which board your opponent must play on next.")
                .font(.system(size: 15))
                .foregroundColor(Color(hex: "#567C8D"))
                .padding(3)
            
            
            Button(action: {
                viewModel.showingInfoScreen = false
                viewModel.showingWinScreen = false
            }) {
                Text("start game")
                    .font(.system(size: 25, weight: .semibold, design: .monospaced))
                    .padding(19)
                    .background(Color(hex: "#C8D9E6"))
                    .foregroundColor(Color(hex: "#567C8D"))
                    .border(Color(hex: "#F5EFEB"), width: 10)
                    .cornerRadius(6)
                    .padding(17)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(hex: "#2F4156"), lineWidth: 7)
                            .padding()
                    )
            }
            .padding()
        }
    }
}

#Preview {
    UltimateTicTacToeView()
}
