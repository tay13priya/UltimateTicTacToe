//
//  Mark.swift
//  UltimateTicTacToe
//
//  Created by Parekh, Priya Zara on 11/8/24.
//

import Foundation

enum Mark: String {
    case x = "X"
    case o = "O"
    case empty = ""
    case draw = "Draw" // Add a new case for draw

    var display: String {
        self.rawValue
    }
}

enum LargeMark: String {
    case x = "X"
    case o = "O"
    case empty = ""
    case draw = "Draw"

    var display: String {
        self.rawValue
    }
}

struct SmallBoard {
    var cells: [Mark] = Array(repeating: .empty, count: 9)
    var winner: Mark = .empty  // Track the winner of the small board

    mutating func checkWin(for mark: Mark) -> Bool {
        let winningCombinations = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6]             // Diagonals
        ]
        let hasWon = winningCombinations.contains { combo in
            combo.allSatisfy { cells[$0] == mark }
        }
        if hasWon {
            winner = mark
        }
        return hasWon
    }
    
    mutating func checkDraw() -> Bool {
        if cells.allSatisfy({ $0 != .empty }) && winner == .empty {
            winner = .draw
            return true
        }
        return false
    }
}
