//
//  CellView.swift
//  UltimateTicTacToe
//
//  Created by Parekh, Priya Zara on 11/8/24.
//
import SwiftUI
struct CellView: View {
    var mark: Mark
    
    

    var body: some View {
        Text(mark.display)
            .font(.largeTitle)
            .foregroundColor(Color(hex: "#2F4156")) 
            .frame(width: 50, height: 50)
            .background(Color(hex: "#C8D9E6"))
            .border(Color(hex: "#C8D9E6"))
            .cornerRadius(4)
    }
    
}
