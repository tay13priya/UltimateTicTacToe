//
//  UltimateTicTacToeModel.swift
//  UltimateTicTacToe
//
//  Created by Parekh, Priya Zara on 11/8/24.
//

import SwiftUI

class UltimateTicTacToeViewModel: ObservableObject {
    @Published var boards: [[SmallBoard]] = Array(repeating: Array(repeating: SmallBoard(), count: 3), count: 3)
    @Published var currentPlayer: Mark = .x
    @Published var currentBoard: (Int, Int)? = nil // Start with no restriction on the board
    @Published var message: String = "Player X's turn"
    @Published var largeMarks: [[Mark]] = Array(repeating: Array(repeating: .empty, count: 3), count: 3)
    @Published var showResetConfirmation: Bool = false
    @Published var gameEnded: Bool = false // Track if the game has ended
    @Published var playerXpoints = 0
    @Published var playerOpoints = 0
    @Published var bigBoardsFilled = 0
    @Published var showingWinScreen: Bool = false
    @Published var showingInfoScreen: Bool = true





    
    /*  func makeMove(boardIndex: (Int, Int), cellIndex: (Int, Int)) {
     let (boardRow, boardCol) = boardIndex
     let (row, col) = cellIndex
     let index = row * 3 + col
     
     print("makeMove called with boardIndex: \(boardIndex), cellIndex: \(cellIndex)")
     print("Current state before move: \(boards[boardRow][boardCol].cells)")
     
     // Check for valid move
     if boards[boardRow][boardCol].cells[index] == .empty, boards[boardRow][boardCol].winner == .empty {
     if let currentBoard = currentBoard {
     print("currentBoard is set to: \(currentBoard)")
     if currentBoard == boardIndex {
     performMove(boardRow: boardRow, boardCol: boardCol, index: index, row: row, col: col)
     } else {
     print("Move not allowed in this board")
     }
     } else {
     print("currentBoard is nil, allowing move in any board")
     performMove(boardRow: boardRow, boardCol: boardCol, index: index, row: row, col: col)
     }
     } else {
     print("Cell already occupied or board is won")
     }
     }*/
    
    func makeMove(boardIndex: (Int, Int), cellIndex: (Int, Int)) {
            let (boardRow, boardCol) = boardIndex
            let (row, col) = cellIndex
            let index = row * 3 + col
            
            print("makeMove called with boardIndex: \(boardIndex), cellIndex: \(cellIndex)")
            print("Current state before move: \(boards[boardRow][boardCol].cells)")
            
            // Prevent moves in won boards
            if boards[boardRow][boardCol].winner != .empty {
                print("Cannot make move in won board: \(boardIndex)")
                return
            }
            
            // Check for valid move
            if boards[boardRow][boardCol].cells[index] == .empty {
                if let currentBoard = currentBoard {
                    print("currentBoard is set to: \(currentBoard)")
                    if currentBoard == boardIndex {
                        performMove(boardRow: boardRow, boardCol: boardCol, index: index, row: row, col: col)
                    } else {
                        print("Move not allowed in this board")
                    }
                } else {
                    print("currentBoard is nil, allowing move in any board")
                    performMove(boardRow: boardRow, boardCol: boardCol, index: index, row: row, col: col)
                }
            } else {
                print("Cell already occupied or board is won")
            }
        }
        
        private func performMove(boardRow: Int, boardCol: Int, index: Int, row: Int, col: Int) {
            boards[boardRow][boardCol].cells[index] = currentPlayer
            print("Updated state after move: \(boards[boardRow][boardCol].cells)")
            
            // Check if the small board winner
            if boards[boardRow][boardCol].checkWin(for: currentPlayer) {
                largeMarks[boardRow][boardCol] = currentPlayer
                if currentPlayer == .x{
                    playerXpoints = playerXpoints + 1
                }
                if currentPlayer == .o{
                    playerOpoints = playerOpoints + 1
                }
                bigBoardsFilled = bigBoardsFilled + 1
                boards[boardRow][boardCol].winner = currentPlayer
                checkLargeBoardWin(for: currentPlayer)
                print("Board \(boardRow),\(boardCol) has a winner: \(currentPlayer.display)")
                
                           
            }
            else if boards[boardRow][boardCol].checkDraw() {
                largeMarks[boardRow][boardCol] = .draw
            }
            
            // Switch player if game continues
            currentPlayer = currentPlayer == .x ? .o : .x
            
            if !gameEnded{
                message = "Player \(currentPlayer.display)'s Turn"
            }
            
            // Set the next board to play in based on where the move was made (row, col)
            if largeMarks[row][col] == .empty {
                currentBoard = (row, col)
            } else {
                currentBoard = nil // Allow the player to choose any board
            }
            
            print("Next currentBoard: \(String(describing: currentBoard))")
            if gameEnded{
                showingWinScreen = true
            }
        }
        
     func checkLargeBoardWin(for mark: Mark){
        print("into the big win func")
         //if the entire big board is filled
        //if horizontal wins
        if largeMarks[0][0] == largeMarks[0][1] && largeMarks[0][1] == largeMarks[0][2] && largeMarks[0][0] != .empty{
            message = "Player \(currentPlayer) Wins!"
            gameEnded = true
        }
        if largeMarks[1][0] == largeMarks[1][1] && largeMarks[1][1] == largeMarks[1][2] && largeMarks[1][0] != .empty{
            message = "Player \(mark.display) Wins!"
            gameEnded = true
        }
        if largeMarks[2][0] == largeMarks[2][1] && largeMarks[2][1] == largeMarks[2][2] && largeMarks[2][0] != .empty{
            message = "Player \(mark.display) Wins!"
            gameEnded = true
        }
        
        //if vertical wins
        if largeMarks[0][1] == largeMarks[1][1] && largeMarks[0][1] == largeMarks[2][1] && largeMarks[2][1] != .empty{
            message = "Player \(mark.display) Wins!"
            gameEnded = true
        }
        if largeMarks[2][0] == largeMarks[0][0] && largeMarks[1][0] == largeMarks[2][0] && largeMarks[2][0] != .empty{
            message = "Player \(mark.display) Wins!"
            gameEnded = true
        }
        if largeMarks[2][2] == largeMarks[1][2] && largeMarks[1][2] == largeMarks[0][2] && largeMarks[0][2] != .empty{
            message = "Player \(mark.display) Wins!"
            gameEnded = true
        }
        
        //if diagonal wins
        if largeMarks[0][0] == largeMarks[1][1] && largeMarks[1][1] == largeMarks[2][2] && largeMarks[0][0] != .empty{
            message = "Player \(mark.display) Wins!"
            gameEnded = true
        }
        if largeMarks[0][2] == largeMarks[1][1] && largeMarks[1][1] == largeMarks[2][0] && largeMarks[2][0] != .empty{
            message = "Player \(mark.display) Wins!"
            gameEnded = true
        }
         
         
         if bigBoardsFilled == 9{
             //whoever has most completed boards wins
             if playerOpoints > playerXpoints{
                 message = "Player O"
                 gameEnded = true
             }
             else if playerXpoints > playerOpoints{
                 message = "Player X"
                 gameEnded = true
             }
             //or its an overall draw
             else{
                 message = "Draw"
                 gameEnded = true
             }
         }
         
        
         currentBoard = nil // No more moves allowed

        
        /*let winningCombinations = [
                [(0, 0), (0, 1), (0, 2)], [(1, 0), (1, 1), (1, 2)], [(2, 0), (2, 1), (2, 2)], // Rows
                [(0, 0), (1, 0), (2, 0)], [(0, 1), (1, 1), (2, 1)], [(0, 2), (1, 2), (2, 2)], // Columns
                [(0, 0), (1, 1), (2, 2)], [(0, 2), (1, 1), (2, 0)]  // Diagonals
            ]
            
            // Check if any of the winning combinations for large board is met
            if winningCombinations.contains(where: { $0.allSatisfy { largeMarks[$0.0][$0.1] == mark } }) {
                message = "Player \(mark.display) Wins the Game!"
                // Mark the entire large board with the winner
                /*for row in 0..<3 {
                    for col in 0..<3 {
                        if largeMarks[row][col] == .empty {
                            largeMarks[row][col] = mark
                        }
                    }
                }
                 */
            }
         */

        }
        
    /*func requestResetConfirmation() {
            showResetConfirmation = true
        }

        func confirmResetGame() {
            resetGame()
            showResetConfirmation = false
        }

        func cancelResetGame() {
            showResetConfirmation = false
        }*/ //this is not working idk man
        
        func resetGame() {
            boards = Array(repeating: Array(repeating: SmallBoard(), count: 3), count: 3)
            currentPlayer = .x
            currentBoard = nil  // Reset to allow the first move anywhere
            message = "Player X's Turn"
            largeMarks = Array(repeating: Array(repeating: .empty, count: 3), count: 3)
            gameEnded = false // Reset game end flag
        }
    }
