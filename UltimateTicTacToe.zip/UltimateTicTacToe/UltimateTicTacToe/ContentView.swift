//
//  ContentView.swift
//  UltimateTicTacToe
//
//  Created by Parekh, Priya Zara on 11/8/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        UltimateTicTacToeView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


#Preview {
    ContentView()
}
 
