//
//  UltimateTicTacToeApp.swift
//  UltimateTicTacToe
//
//  Created by Parekh, Priya Zara on 11/8/24.
//

import SwiftUI

@main
struct UltimateTicTacToeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
